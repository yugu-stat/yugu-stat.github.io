#define ARMA_DONT_PRINT_ERRORS
#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;

#include<iostream>
#include<vector>

struct SCORE_INFO {
    arma::vec score_beta;
    arma::vec score_gamma;
    arma::mat info;
    double loglikelihood;
};

// calculate score and information for an individual subject
SCORE_INFO calculate_score_info(arma::vec Si, arma::mat Xi, arma::vec time_i, arma::vec unique_time, arma::vec unique_score, arma::vec unique_score_idx, arma::vec beta, arma::vec gamma, arma::vec exp_gamma_cumsum, arma::vec gamma_idx, int n_para) {
    // gamma_cumsum records sum_{l <= k} exp(gamma_{lt})
    int ni = Xi.n_rows; // ni = T
    int p  = Xi.n_cols;
    // initialize score and information
    SCORE_INFO score_info;
    score_info.score_beta = arma::zeros(p);
    score_info.score_gamma = arma::zeros(n_para - p);
    score_info.info = arma::zeros(n_para, n_para);
    score_info.loglikelihood = 0.0;

    // useful variables
    double tmp, EXbeta_i, tmp1, tmp2;
    int k;
    for (int t = 0; t < ni; t++) {
        EXbeta_i = std::exp(arma::as_scalar(Xi.row(t) * beta));
        arma::uvec ti = arma::find(unique_time == time_i(t));
        arma::vec possible_score_i = unique_score.subvec(unique_score_idx(ti(0)), unique_score_idx(ti(0) + 1) - 1);
        int Kti = possible_score_i.size();
        // gamma.subvec(gamma_idx(t), gamma_idx(t + 1) - 1) is the intercept for day unique_time(t), gamma_{t.}
        arma::vec gamma_ti = gamma.subvec(gamma_idx(ti(0)), gamma_idx(ti(0) + 1) - 1);
        arma::vec exp_gamma_cumsum_ti = exp_gamma_cumsum.subvec(gamma_idx(ti(0)), gamma_idx(ti(0) + 1) - 1);
        if (Si(t) == possible_score_i(0)) {
            tmp = 1.0 / (1.0 + std::exp(gamma_ti(0)) * EXbeta_i);
            // calculate score
            score_info.score_beta += tmp * Xi.row(t).t();
            score_info.score_gamma(gamma_idx(ti(0))) += tmp;
            // calculate info
            // submat(first_row, first_col, last_row, last_col)
            score_info.info.submat(0, 0, p - 1, p - 1) += (tmp - 1.0) * tmp * Xi.row(t).t() * Xi.row(t);
            score_info.info.submat(0, p + gamma_idx(ti(0)), p - 1, p + gamma_idx(ti(0))) += (tmp - 1.0) * tmp * Xi.row(t).t();
            score_info.info.submat(p + gamma_idx(ti(0)), 0, p + gamma_idx(ti(0)), p - 1) = score_info.info.submat(0, p + gamma_idx(ti(0)), p - 1, p + gamma_idx(ti(0))).t();
            score_info.info(p + gamma_idx(ti(0)), gamma_idx(ti(0)) + p) += (tmp - 1.0) * tmp;

            score_info.loglikelihood += gamma_ti(0) + std::log(EXbeta_i) - std::log(1 + EXbeta_i * std::exp(gamma_ti(0)));
        } else if (Si(t) == possible_score_i(Kti - 1)) {
            tmp = 1.0 / (1.0 + exp_gamma_cumsum_ti(Kti - 2) * EXbeta_i);
            // calculate score
            score_info.score_beta += (tmp - 1.0) * Xi.row(t).t();
            score_info.score_gamma.subvec(gamma_idx(ti(0)), gamma_idx(ti(0) + 1) - 1) -= arma::exp(gamma_ti) * EXbeta_i * tmp;
            // calculate info
            score_info.info.submat(0, 0, p - 1, p - 1) += (tmp - 1.0) * tmp * Xi.row(t).t() * Xi.row(t);
            for (int l = 0; l < Kti - 1; l++) {
                score_info.info.submat(0, p + gamma_idx(ti(0)) + l, p - 1, p + gamma_idx(ti(0)) + l) += -std::exp(gamma_ti(l)) * EXbeta_i * tmp * tmp * Xi.row(t).t();
                score_info.info.submat(p + gamma_idx(ti(0)) + l, 0, p + gamma_idx(ti(0)) + l, p - 1) = score_info.info.submat(0, p + gamma_idx(ti(0)) + l, p - 1, p + gamma_idx(ti(0)) + l).t();
            }

            score_info.info.submat(p + gamma_idx(ti(0)), p + gamma_idx(ti(0)), p + gamma_idx(ti(0) + 1) - 1, p + gamma_idx(ti(0) + 1) - 1) += arma::exp(gamma_ti) * arma::exp(gamma_ti.t()) * EXbeta_i * EXbeta_i * tmp * tmp;

            for (int l = 0; l < Kti - 1; l++) {
                score_info.info(p + gamma_idx(ti(0)) + l, p + gamma_idx(ti(0)) + l) -= tmp * EXbeta_i * std::exp(gamma_ti(l));
            }

            score_info.loglikelihood += -std::log(1 + EXbeta_i * exp_gamma_cumsum_ti(Kti - 2));

        } else {

            arma::uvec ki = arma::find(possible_score_i == Si(t));
            k = ki(0); //k=1,2,...,Kti-2

            tmp1 = 1.0 / (1.0 + exp_gamma_cumsum_ti(k) * EXbeta_i);
            tmp2 = 1.0 / (1.0 + exp_gamma_cumsum_ti(k - 1) * EXbeta_i);

            // calculate score
            score_info.score_beta +=  (tmp1 + tmp2 - 1.0) * Xi.row(t).t();

            score_info.score_gamma(gamma_idx(ti(0)) + k) += 1.0 - std::exp(gamma_ti(k)) * EXbeta_i * tmp1;

            for (int l = 0; l < k; l++) {
                score_info.score_gamma(gamma_idx(ti(0)) + l) -= (tmp1 + tmp2) * std::exp(gamma_ti(l)) * EXbeta_i;
            }

            // calculate info
            score_info.info.submat(0, 0, p - 1, p - 1) += (tmp1 * (tmp1 - 1.0) + tmp2 * (tmp2 - 1.0)) * Xi.row(t).t() * Xi.row(t);
            score_info.info.submat(0, p + gamma_idx(ti(0)) + k, p - 1, p + gamma_idx(ti(0)) + k) -= std::exp(gamma_ti(k)) * EXbeta_i * tmp1 * tmp1 * Xi.row(t).t();
            score_info.info.submat(p + gamma_idx(ti(0)) + k, 0, p + gamma_idx(ti(0)) + k, p - 1) = score_info.info.submat(0, p + gamma_idx(ti(0)) + k, p - 1, p + gamma_idx(ti(0)) + k).t();

            for (int l = 0; l < k; l++) {
                score_info.info.submat(0, p + gamma_idx(ti(0)) + l, p - 1, p + gamma_idx(ti(0)) + l) -= (tmp1 * tmp1 + tmp2 * tmp2) * EXbeta_i * std::exp(gamma_ti(l)) * Xi.row(t).t();
                score_info.info.submat(p + gamma_idx(ti(0)) + l, 0, p + gamma_idx(ti(0)) + l, p - 1) = score_info.info.submat(0, p + gamma_idx(ti(0)) + l, p - 1, p + gamma_idx(ti(0)) + l).t();
            }

            score_info.info.submat(p + gamma_idx(ti(0)), p + gamma_idx(ti(0)), p + gamma_idx(ti(0)) + k - 1, p + gamma_idx(ti(0)) + k - 1) += arma::exp(gamma_ti.subvec(0, k - 1)) * arma::exp(gamma_ti.subvec(0, k - 1).t()) * EXbeta_i * EXbeta_i * (tmp1 * tmp1 + tmp2 * tmp2);
            score_info.info(p + gamma_idx(ti(0)) + k, p + gamma_idx(ti(0)) + k) += -tmp1 * tmp1 * std::exp(gamma_ti(k)) * EXbeta_i / tmp2;

            for (int l = 0; l < k; l++) {
                score_info.info(p + gamma_idx(ti(0)) + l, p + gamma_idx(ti(0)) + l) += -(tmp1 + tmp2) * EXbeta_i * std::exp(gamma_ti(l));// + tmp1 * tmp1 * EXbeta_i * std::exp(gamma(l - 1, t)) * EXbeta_i * std::exp(gamma(l - 1, t)) + tmp2 * tmp2 * EXbeta_i * std::exp(gamma(l - 1, t)) * EXbeta_i * std::exp(gamma(l - 1, t));
            }

            for (int l = 0; l < k; l++) {
                score_info.info(p + gamma_idx(ti(0)) + l, p + gamma_idx(ti(0)) + k) += tmp1 * tmp1 * EXbeta_i * EXbeta_i * std::exp(gamma_ti(k)) * std::exp(gamma_ti(l));
                score_info.info(p + gamma_idx(ti(0)) + k, p + gamma_idx(ti(0)) + l) = score_info.info(p + gamma_idx(ti(0)) + l, p + gamma_idx(ti(0)) + k);
            }
            score_info.loglikelihood += gamma_ti(k) + std::log(EXbeta_i) - std::log(1 + EXbeta_i + exp_gamma_cumsum_ti(k)) - std::log(1 + EXbeta_i * exp_gamma_cumsum_ti(k - 1));

        }
    }
    return score_info;
}

// [[Rcpp::export]]
Rcpp::List po_gee(arma::vec S, arma::mat X, arma::vec time, std::vector<std::string> subject, int max_iter = 50, double epsilon = 1e-6, double learning_rate = 0.1, bool message = true) {
    // K, number of categories
    // categories, 1,2,3,...,K
    // T, total follow-up times
    // Y, longitudinal outcomes
    // subject, subject id
    // time, follow-up times
    // X, covariates
    int p = X.n_cols;
    // find unique times
    arma::vec unique_time = arma::unique(time);
    int T = unique_time.size();
    // number of unique subjects
    std::vector<std::string> v = subject;
    std::sort(v.begin(), v.end());
    int n_patients = std::unique(v.begin(), v.end()) - v.begin();
    // subject index
    // unique_subject_idx(i):unique_subject_idx(i+1)-1 are the index for the ith patient, i=0, ..., n_patient
    arma::vec unique_subject_idx = arma::zeros(n_patients + 1);
    int j = 1;
    for (int i = 0; i < n_patients; i++) {
        while (j < subject.size() && subject[j] == subject[j - 1]) {
            j++;
        }
        unique_subject_idx(i + 1) = j;
        j++;
    }
    // find number of possible values for each day
    // unique_score_num(t): number of possible value for day unique_time(t)
    arma::vec unique_score_num(T);
    for (int t = 0; t < T; t++) {
        arma::uvec idx = arma::find(time == unique_time(t));
        arma::vec unique_score_t = arma::unique(S(idx));
        unique_score_num(t) = unique_score_t.size();
    }

    // total number of parameters
    int n_para = p + arma::sum(unique_score_num) - T;
    // store possible value for each day in a vector
    arma::vec unique_score = arma::vec(n_para - p + T);
    arma::vec unique_score_idx = arma::zeros(T + 1);
    // unique_score.subvec(unique_score_idx(t), unique_score_idx(t+1)-1) are the possible scores for day unique_time(t);
    int start = 0;
    for (int t = 0; t < T; t++) {
        arma::uvec idx = arma::find(time == unique_time(t));
        arma::vec unique_score_t = arma::unique(S(idx));
        unique_score.subvec(start, start + unique_score_t.size() - 1) = unique_score_t;
        start += unique_score_t.size();
        unique_score_idx(t + 1) = start;
    }
    // gamma_t index
    // gamma.subvec(gamma_idx(t), gamma_idx(t + 1) - 1) is the intercept for day unique_time(t), gamma_{t.}
    arma::vec gamma_idx = arma::zeros(T + 1);
    start = 0;
    for (int t = 0; t < T; t++) {
        start += unique_score_num(t) - 1;
        gamma_idx(t + 1) = start;
    }
    // initialize beta, gamma, and alpha = cumum of exp(gamma)
    arma::vec beta(p);
    arma::vec gamma(n_para - p); // gamma_{tk} (1<= k <= K_{t})
    beta.zeros();
    gamma.zeros();
    arma::vec exp_gamma_cumsum(n_para - p);
    for (int t = 0; t < T; t++) {
        exp_gamma_cumsum.subvec(gamma_idx(t), gamma_idx(t + 1) - 1) = arma::cumsum(arma::exp(gamma.subvec(gamma_idx(t), gamma_idx(t + 1) - 1)));
    }

    arma::vec score(n_para), gradient(n_para), score_i(n_para);
    arma::mat hessian(n_para, n_para);
    score.zeros(); hessian.zeros();
    SCORE_INFO score_info_i;
    arma::vec Si;
    arma::mat Xi;
    arma::vec time_i;
    double eps = 1.0;
    int iter = 0;
    double logL, logL_old;
    logL_old = -INFINITY;

    //arma::vec beta_old(p), gradient_old(n_para);
    //beta_old.zeros(); gradient_old.zeros();
    //arma::vec gamma_old(n_para - p);
    //gamma_old.zeros();

    arma::mat score_mat(n_patients, n_para); // used to calculate robust variance estimator
    
    while (eps >= epsilon && iter < max_iter) {
        iter++;
        score.zeros(); hessian.zeros();
        logL = 0;
        for (int i = 0; i < n_patients; i++) {
            Si = S.subvec(unique_subject_idx(i), unique_subject_idx(i + 1) - 1); // outcomes for subject i
            Xi = X.rows(unique_subject_idx(i), unique_subject_idx(i + 1) - 1); // covariates for subject i
            time_i = time.subvec(unique_subject_idx(i), unique_subject_idx(i + 1) - 1); // time for subject i
            
            
            score_info_i = calculate_score_info(Si, Xi, time_i, unique_time, unique_score, unique_score_idx, beta, gamma, exp_gamma_cumsum, gamma_idx, n_para);
            
            // update score
            score_i.subvec(0, p - 1) = score_info_i.score_beta;
            score_i.subvec(p, n_para - 1) = score_info_i.score_gamma;
            score += score_i;
            hessian += score_info_i.info;
            logL += score_info_i.loglikelihood;

            score_mat.row(i) = score_i.t();
        }

        gradient = learning_rate * arma::solve(-hessian, score);
        //beta_old = beta;
        //gamma_old = gamma;


        beta += gradient.subvec(0, p - 1);
        gamma += gradient.subvec(p, n_para - 1);
        for (int t = 0; t < T; t++) {
            exp_gamma_cumsum.subvec(gamma_idx(t), gamma_idx(t + 1) - 1) = arma::cumsum(arma::exp(gamma.subvec(gamma_idx(t), gamma_idx(t + 1) - 1)));
        }

        eps = fabs((logL - logL_old) / logL);
        logL_old = logL;
        if (message) {
            std::cout << "beta: " << beta.t() << std::endl;
            std::cout << "epsilon: " << eps <<  " log likelihood: " << logL << std::endl;
        }


    }


    // calculate robust variance estimator
    for (int t = 0; t < T; t++) {
        exp_gamma_cumsum.subvec(gamma_idx(t), gamma_idx(t + 1) - 1) = arma::cumsum(arma::exp(gamma.subvec(gamma_idx(t), gamma_idx(t + 1) - 1)));
    }
    score.zeros(); hessian.zeros();
    logL = 0.0;
    for (int i = 0; i < n_patients; i++) {
        Si = S.subvec(unique_subject_idx(i), unique_subject_idx(i + 1) - 1); // outcomes for subject i
        Xi = X.rows(unique_subject_idx(i), unique_subject_idx(i + 1) - 1); // covariates for subject i
        time_i = time.subvec(unique_subject_idx(i), unique_subject_idx(i + 1) - 1); // time for subject i
        score_info_i = calculate_score_info(Si, Xi, time_i, unique_time, unique_score, unique_score_idx, beta, gamma, exp_gamma_cumsum, gamma_idx, n_para);

        score_i.subvec(0, p - 1) = score_info_i.score_beta;
        score_i.subvec(p, n_para - 1) = score_info_i.score_gamma;
        score += score_i;
        hessian += score_info_i.info;
        logL += score_info_i.loglikelihood;

        score_mat.row(i) = score_i.t();
    }
    arma::mat inv_hessian = arma::inv(hessian);
    arma::mat robust_cov = inv_hessian * arma::cov(score_mat) * inv_hessian.t() * n_patients;
    //Rcpp::List res;
    arma::mat alpha = arma::log(exp_gamma_cumsum);
    Rcpp::List res;
    res["beta"] = beta;
    res["gamma"] = gamma;
    res["alpha"] = alpha;
    res["n_iter"] = iter;
    res["score"] = score;
    res["hessian"] = hessian;
    res["cov"] = robust_cov;
    res["logL"] = logL;
    res["logL_old"] = logL_old;
    res["gradient"] = gradient;
    res["eps"] = eps;
    if (eps >= epsilon) {
        std::cout << "does not converge in " << iter << " iterations" << std::endl;
        res["converge"] = false;
    } else {
        res["converge"] = true;
    }
    return res;
}

