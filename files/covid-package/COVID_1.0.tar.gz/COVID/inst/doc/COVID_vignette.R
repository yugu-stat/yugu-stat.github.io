## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
opt <- options()
options(continue="  ", width=70, prompt=" ")
on.exit(options(opt))
library(COVID, quietly=TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  outcome(examination.time, clinical.status)

## ----usage, eval=FALSE--------------------------------------------------------
#  ph(formula, data, subject,
#     treatment, init.status, nmin = 5)

## ----outcome-usage, eval=FALSE------------------------------------------------
#  outcome(examination_time, clinical_status) ~ treatment_arm + covariates

## ----proportional-odds-modelling-usage, eval=FALSE----------------------------
#  po = function(formula, data, subject, treatment,
#                imputation = F,
#                common.odds.ratio = T,
#                piecewise.linear = T,
#                intercept = T,
#                knots = NULL,
#                control.ngd = list(learning.rate = 0.1,
#                                   max.iter = 1000,
#                                   eps = 1e-6,
#                                   messages = F),
#                start.time = NULL, end.time = NULL,
#                imputed.score = 7)

## ----data-load----------------------------------------------------------------
data(acttData)

## ----data-head----------------------------------------------------------------
head(acttData)

## ----data-summary-------------------------------------------------------------
summary(acttData)

## ----proportional-hazards-modelling, echo=TRUE, eval=TRUE---------------------
model <- outcome(examination_time, clinical_status) ~ treatment_arm + baseline_severity
result1 <- ph(formula = model, 
              data = acttData,
              subject = "subject_id",
              treatment = "treatment_arm",
              init.status = "initial_status")

## ----result1, echo=TRUE, eval=TRUE--------------------------------------------
result1

## ----proportional.odds.modelling, echo=TRUE, eval=TRUE------------------------
model <- outcome(examination_time, clinical_status) ~ treatment_arm + baseline_severity
result2 <- po(formula = model,
              data = acttData,
              subject = 'subject_id',
              treatment = 'treatment_arm',
              imputation = T,
              knots = c(0, 4, 10, 14, 16, 26),
              start.time = 1, end.time = 28)

## ----result2-common-odds-ratio, echo=TRUE, eval=TRUE--------------------------
result2$common.odds.ratio

## ----separate-model, echo=TRUE, eval=TRUE-------------------------------------
result2$separate.model

## ----plot, echo=TRUE, eval=TRUE, fig.align='center', out.width='70%'----------
result2$piecewise.linear$plot

