#' Specify Outcome Variables
#'
#' This function is used to specify the examination time and the clinical status 
#' in the model statement of \code{ph()}
#' and \code{po()}. 
#'
#' @param examination.time The variable for the time when 
#'   the subject is examined for clinical status. NA if missing.
#'   
#' @param clinical.status The variable for the clinical status at each examination.
#'   Must be integer and take values among 1, 2, ..., K, where K is the total number 
#'   of categories. NA if missing.
#'
#' @returns This function is intended to be used only in the model statement 
#'  of ph() and po(). 
#'  The result, a matrix, is used internally.
#'    
#' @name outcome
#' @rdname outcome
#' @export

outcome <- function(examination.time, clinical.status) {
  
  ### examination.time
  
  # must be provided as a numeric vector. 
  
  if (missing(x = examination.time)) {
    stop("must provide a examination.time argument", 
         call. = FALSE)
  }
  
  if (!is.numeric(x = examination.time)) {
    stop ("examination.time is not numeric", call. = FALSE)
  }

  
  ### clinical.status
  
  # must be provided as a numeric vector
  
  if (missing(x = clinical.status)) {
    stop("must provide a clinical.status argument", call. = FALSE)
  }
  if (length(x = clinical.status) != length(x = examination.time)) {
    stop("Inputs must be of same length", call. = FALSE)
  }
  
  if (is.factor(x = clinical.status)) {
    # clinical.status provided as a factor - convert to integer level ids
    stat <- match(x = levels(x = clinical.status)[clinical.status],
                  table = levels(x = clinical.status))
  } else if (is.numeric(x = clinical.status)) {
    # clinical.status provided as numeric - convert to integer
    stat <- as.integer(x = round(x = clinical.status, digits = 0L))
  } else {
    stop("invalid clinical.status input, must be numeric", 
         call. = FALSE)
  }

  
  dm <- cbind(examination.time, clinical.status)
  
  cname <- c("examination.time", "clinical.status")
  dimnames(x = dm) <- list(NULL, cname)
  
  return( dm )
}
