#' Treatment Effects on Changes of Clinical Status Over Time
#' 
#' Different levels of improvement or deterioration from the clinical status 
#' at randomization are viewed as multiple events. 
#' Treatment effect on each event is formulated through a Cox
#' proportional hazards model, stratified by the initial status.  
#' The covariance matrix of all the estimated treatment effects is estimated 
#' using the Wei, Lin and Weissfeld (1989) method.
#' Z-scores are used or combined to test various null hypotheses, including
#' no treatment effect on a particular event, no treatment effect on any improvement 
#' or deterioration, and no overall benefits.
#' 
#' The information required for an analysis is 
#'   \describe{
#'     \item{Subject ID:}{The variable used to identify subjects.}
#'     \item{Treatment arm:}{The binary indicator of the treatment arm, 
#'        1 for the treatment group and 0 for the placebo group.}
#'     \item{Initial Status:}{The clinical status at randomization. NA if missing.}
#'     \item{Examination Time:}{The times when the subject is examined for clinical status.
#'       NA if missing.}
#'     \item{Clinical Status:}{The clinical status of the subject at each examination.
#'       NA if missing.}
#'     \item{Covariates:}{Baseline covariates.}
#'    }
#' 
#' The input data should be in the long format, i.e., each row pertains to 
#' one examination of one subject.
#' The subject ID can be numeric or character.
#' The treatment arm must be 0/1, with 0 and 1 representing the placebo and the treatment 
#' arms, respectively. 
#' The examination time must be non-negative integer.
#' The clinical status must be integer, with values 1, 2, ..., K, where K is the 
#' total number of categories.
#' The larger the status, the worse the clinical outcome.   
#' The covariates can include categorical variables, for which
#' all other categories are compared to the first category.
#' A model without covariates is also allowed.   
#' 
#' The general structure of the formula input is
#'   \preformatted{
#'   outcome(examination_time, clinical_status) ~ treatment_arm + covariates 
#'   }
#' 
#' The left-hand side contains the information about the examination time and 
#' the corresponding clinical status. It must be
#' specified through function \code{outcome()}. Specifically, 
#' \preformatted{outcome(examination_time, clinical_status)}
#' 
#' @rdname ph
#' @name ph
#' 
#' @references Lin DY, Wang J, Gu Y, Zeng D (2022). 
#'   Evaluating Treatment Efficacy in Hospitalized Covid-19 Patients. Submitted.
#' 
#'   Wei LJ, Lin DY, Weissfeld L (1989). 
#'   Regression analysis of multivariate incomplete failure time data by modeling marginal distributions. 
#'   J Am Stat Ass, 84: 1065-1073.
#' 
#' @param formula A formula object, with all of the outcome variables
#'   on the left hand side of a \code{~} operator and the treatment and covariates 
#'   on the right. The outcome variables must be specified through the \code{outcome()} function. 
#'   See \code{?outcome} and Details for further information. 
#'   
#' @param data A data.frame object. The data.frame in which to interpret the
#'   variable names in formula. Must contain the subject ID, the treatment arm, 
#'   the initial status, the examination time, the clinical status measured  
#'   at each examination, and any covariates. 
#'   See Details.
#'   
#' @param subject A character string. Name of the variable in data which 
#'   identifies multiple rows from the same subject.
#'   
#' @param treatment A character string. Name of the variable in data that 
#'   corresponds to treatment arm. 
#'   
#' @param init.status A character string. Name of the variable in data that 
#'   corresponds to initial status. 
#'   
#' @param nmin A positive integer object. The minimum number of cases for an event
#'   to be taken into account. Any event with fewer cases than this number will not 
#'   be modelled. The default value is 5. 
#'   
#' @returns A matrix containing the estimated hazard ratio of treatment for each endpoint,
#'   together with the 95\% confidence interval and the two-sided p-value for testing 
#'   no treatment effect. 
#'
#' @export
#' @import stats dplyr
#'
#' @useDynLib COVID
#' 
#' @include cox_wlw.R 
#' 
#' @examples
#' data(acttData)
#' model <- outcome(examination_time, clinical_status) ~ treatment_arm + baseline_severity
#' ph(formula = model, 
#'    data = acttData,
#'    subject = "subject_id",
#'    treatment = "treatment_arm",
#'    init.status = "initial_status")

ph = function(formula, 
              data, 
              subject, 
              treatment, 
              init.status, 
              nmin = 5) {
  
  if (missing(x = formula)) {
    stop("a formula argument must be provided", call. = FALSE)
  }
  
  if (missing(x = data)) {
    stop("a data argument must be provided", call. = FALSE)
  }
  
  # reset options to allow for keeping na values
  opt <- options()
  options(na.action = 'na.pass')
  
  # add intercept from model if not provided to ensure that factors are handled properly
  if (attr(x = stats::terms(x = formula), which = "intercept") == 0L) {
    formula = update.formula(old = formula, new = .~. +1)
  }
  
  # try to obtain the model.frame
  mf <- tryCatch(expr = stats::model.frame(formula = formula, data = data),
                 error = function(e) {
                   message("unable to obtain model.frame")
                   stop(e$message, call. = FALSE)
                 })
  
  # extract covariates
  X <- suppressMessages(stats::model.matrix(object = mf, data = data))
  # remove intercept
  int <- attr(x = X, which = "assign") != 0L
  X <- X[,int, drop = FALSE]
  
  # remove treatment from X
  to_rem = which(colnames(X)==treatment)
  X = X[,-to_rem, drop = FALSE]
  
  if (ncol(x = X) == 0L) X <- NULL
  
  
  # extract day and outcome variables
  dt <- suppressMessages(stats::model.response(data = mf))
  if(!all.equal(colnames(dt), c("examination.time", "clinical.status"))) {
    stop("the LHS of formula did not contain an appropriate outcome() object",
         call. = FALSE)
  }

  
  # create a data.frame containing all variables, similar to ACTT data
  newdata = data.frame("id" = data[[subject]],
                       "treatment" = data[[treatment]],
                       "score0" = data[[init.status]],
                       "day" = dt[,1L],
                       "score" = dt[,2L]) 
  
  if(!is.null(X)) {
    newdata = cbind(newdata, X) 
  }
  
  newdata = newdata %>%
    group_by(id) %>%
    arrange(day, .by_group = T) %>%
    as.data.frame()
    
  
  # total numebr of categories
  K = length(unique(na.omit(newdata$score)))
  
  # covariate names
  vnames = colnames(X)
  
  # change options back to the default setting
  options(opt)

  res = analyze_cox_wlw(newdata, vnames, nmin, K)
  
  return(res)
  
}