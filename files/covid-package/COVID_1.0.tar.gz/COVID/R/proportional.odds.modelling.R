#' Treatment Effects on Odds Ratio of Lower Severity over Time
#'
#' Treatment effect on the clinical status is characterized by
#' the odds ratio of lower severity under a series of proportional odds models.
#' The overall treatment effect over a time window is captured by 
#' a common odds ratio of lower severity over time.
#' A piecewise log-linear odds ratio of lower severity over time
#' can be estimated.
#' Missing values can be imputed internally by carrying the
#' last observation forward.
#'
#' The piecewise linear function for the log odds raio
#' is determined by the \code{intercept} and \code{knots}.
#' If the intercept is excluded from the piecewise linear function,
#' the model assumes no treatment effect on the odds ratio of lower severity 
#' at examination time zero. 
#' The knots are the change points in the piecewise linear function.
#' For example, if we assume the treatment effect on log odds ratio of lower severity
#' has change points at examination time 0, 8, 15, 21, 
#' the input argument should be \code{knots = c(0, 8, 15, 21)}.
#' 
#' We use natural gradient ascent algorithm to maximize the log likelihood function of
#' the proportional odds model. 
#' The natural gradient ascent algorithm has four hyperparameters
#' \itemize{
#' \item \code{learning.rate} determines the step size for natural gradient ascent algorithm. 
#'     Must be numeric.
#'     The default value is 0.1.
#' \item \code{max.iter} is the maximum number of iterations for natural gradient ascent algorithm. 
#'     Must be integer.
#'     The default value is 1000.
#' \item \code{eps} is the convergence threshold for natural gradient ascent algorithm. 
#'     Must be numeric.
#'     The default value is \code{1e-6}.
#' \item \code{messages} decides whether to print out the coefficient estimates 
#'     and log likelihood during optimization. 
#'     Must be logical.
#'     The default value is \code{FALSE}.
#' }
#' 
#' @references Lin DY, Wang J, Gu Y, Zeng D (2022). 
#'   Evaluating Treatment Efficacy in Hospitalized Covid-19 Patients. Submitted.
#'   
#' @param formula A formula object, with all of the outcome variables
#'   on the left hand side of a \code{~} operator and the treatment and covariates 
#'   on the right. The outcome variables must be specified through the \code{outcome()} function. 
#'   See \code{?outcome} and \code{?ph} for further information.
#'   
#' @param data A data.frame object. The data.frame in which to interpret the
#'   variable names in formula. Must contain the subject ID, the treatment arm, 
#'   the examination time, the clinical status measured  
#'   at each examination, and any covariates. The clinical status must contain 
#'   at least two categories at each examination time.
#'   See \code{?ph} for further information.
#'   
#' @param subject A character string. Name of the variable in data which 
#'   identifies multiple rows from the same subject.
#'   
#' @param treatment A character string. Name of the variable in data that 
#'   corresponds to treatment arm. 
#'     
#' @param common.odds.ratio Logical. Whether the common odds ratio of
#'     lower severity over time for treatment versus placebo is estimated.
#'     The default value is TRUE.
#' 
#' @param piecewise.linear Logical. Whether a piecewise log-linear odds ratio 
#'     of lower severity over time is estimated
#'     and whether daily odds ratios of lower severity are estimated by
#'     separate proportional odds models.
#'     The default value is TRUE.
#'     See Details for further information.
#'     
#' @param intercept Logical. Whether intercept is included for the piecewise linear 
#'     function while assuming a piecewise log-linear odds ratio over time.
#'     The default value is TRUE.
#'     See Details for further information.
#' 
#' @param knots An integer vector or NULL, The potential change points in days of the
#'     piecewise log-linear odds ratio.
#'     See Details for further information.
#'     If NULL, the function will set change points at the start of every week.
#' 
#' @param control.ngd List, with hyperparameters for natual gradient ascent algorithm. 
#'     See Details for further information.
#'     
#' @param imputation Logical. Whether the input data is imputed by carrying the last observation forward.
#'     The default value if FALSE.
#'     
#' @param start.time Non-negative integer or \code{NULL}. The first examination day included in the analysis. 
#'     If NULL, the first examination day is day 1 for estimating the common odds ratio and day 0 for 
#'     estimating the piecewise log-linear odds ratio.
#' 
#' @param end.time Non-negative integer or \code{NULL}. The last examination day included in the analysis. 
#'     If NULL, the last examination day is day 28 for estimating the common odds ratio 
#'     and the piecewise log-linear odds ratio.
#'     
#' @param imputed.score Integer. The clinical status used for imputation 
#'     when there are no measurements for a subject.
#'     The default value is 7.
#'     
#' @returns A list object with the following elements:
#' 
#' \item{common.odds.ratio}{A list object contains common odds ratio estimate of lower severity over time
#'     for treatment versus placebo and its 95\% confidence interval.}
#' \item{piecewise.linear}{A list object contains change points, coefficient estimates, 
#'     and covariance matrix estimates for piecewise linear model. 
#'     It also contains a plot showing the estimated piecewise log-linear odds ratios and daily odds ratios, with
#'     corresponding 95\% confidence intervals.}
#' \item{separate}{A data.frame object contains the estimated daily odds ratios of lower severity for
#'     treatment versus placebo, together with corresponding 95\% confidence intervals, under separate proportional odds models.}
#' 
#' @examples 
#' data(acttData)
#' model <- outcome(examination_time, clinical_status) ~ treatment_arm + baseline_severity
#' po(formula = model,
#'    data = acttData,
#'    subject = 'subject_id',
#'    treatment = 'treatment_arm',
#'    imputation = T,
#'    knots = c(0, 8, 13, 17, 24),
#'    start.time = 1,
#'    end.time = 28)
#' @useDynLib COVID
#' @import ggplot2
#' @import Rcpp
#' @export
po = function(formula, 
              data, 
              subject, 
              treatment,
              imputation = F,
              common.odds.ratio = T, 
              piecewise.linear = T, 
              intercept = T, 
              knots = NULL,
              control.ngd = list(learning.rate = 0.1, max.iter = 1000,
                                 eps = 1e-6, messages = F),
              start.time = NULL, end.time = NULL,
              imputed.score = 7) {
    if (missing(x = formula)) {
        stop("a formula argument must be provided", call. = FALSE)
    }
    
    if (missing(x = data)) {
        stop("a data argument must be provided", call. = FALSE)
    }
    
    # reset options to allow for keeping na values
    opt <- options()
    options(na.action = 'na.pass')
    # add intercept from model if not provided to ensure that factors are handled properly
    if (attr(x = stats::terms(x = formula), which = "intercept") == 0L) {
        formula = update.formula(old = formula, new = .~. +1)
    }
    # try to obtain the model.frame
    mf <- tryCatch(expr = stats::model.frame(formula = formula, data = data),
                   error = function(e) {
                       message("unable to obtain model.frame")
                       stop(e$message, call. = FALSE)
                   })
    # extract covariates
    X <- suppressMessages(stats::model.matrix(object = mf, data = data))
    # remove intercept
    int <- attr(x = X, which = "assign") != 0L
    X <- X[,int, drop = FALSE]
    
    # remove treatment from X
    to_rem = which(colnames(X)==treatment)
    X = X[,-to_rem, drop = FALSE]
    
    if (ncol(x = X) == 0L) X <- NULL
    
    
    # extract day and outcome variables
    dt <- suppressMessages(stats::model.response(data = mf))
    if(!all.equal(colnames(dt), c("examination.time", "clinical.status"))) {
        stop("the LHS of formula did not contain an appropriate outcome() object",
             call. = FALSE)
    }
    
    
    # create a data.frame containing all variables, similar to ACTT data
    newdata = data.frame("id" = data[[subject]],
                         "treatment" = data[[treatment]],
                         "day" = dt[,1L],
                         "score" = dt[,2L]) 
    
    if(!is.null(X)) {
        newdata = cbind(newdata, X) 
    }
    
    # specify parameters of natual gradient descent
    if (is.null(control.ngd[['learning.rate']])) {
        control.ngd[['learning.rate']] = 0.1
    }
    if (is.null(control.ngd[['max.iter']])) {
        control.ngd[['max.iter']] = 1000
    }
    if (is.null(control.ngd[['eps']])) {
        control.ngd[['eps']] = 1e-6
    }
    if (is.null(control.ngd[['messages']])) {
        control.ngd[['messages']] = F
    }
    
    # set start time and end time
    if (is.null(start.time)) {
        start_time1 = 1
        start_time2 = 0
    } else {
        if (start.time < 0) {
            stop('Negative start time is provided.', call. = FALSE)
        }
        start_time1 = start.time
        start_time2 = start.time
    }
    
    if (is.null(end.time)) {
        end_time1 = 28
        end_time2 = 28
    } else{
        if (end.time < 0) {
            stop('Negative end time is provided.', call. = FALSE)
        }
        end_time1 = end.time
        end_time2 = end.time
    }
    
    if (imputation) {
        # start imputation, last observation carried forward
        print("start imputation")
        imputed.data = last_obs_carried_forward(data = newdata,
                                                score = 'score',
                                                subject = 'id',
                                                time = 'day',
                                                start.time = start_time2,
                                                end.time = end_time2,
                                                imputed.score = imputed.score)
        print("end imputation")
        # end imputation
    } else {
        imputed.data = newdata
    }
    
    
    # confidence interval level
    alpha = 0.05
    
    res = list()
    if (common.odds.ratio) {
        imputed.data1 = imputed.data[which(imputed.data$day >= start_time1 & imputed.data$day <= end_time1), ]
        # fit proportional odds model with common odds ratio
        # start model fitting
        print("start estimating common odds ratio")
        rm_col = which(colnames(imputed.data1) %in% c('score', 'day', 'id'))
        X.common.odds.ratio = data.matrix(imputed.data1[, -rm_col])
        fit.common.odds.ratio = po_gee(S = imputed.data1[['score']], 
                                       X = X.common.odds.ratio,
                                       subject = as.character(imputed.data1[['id']]),
                                       time = as.numeric(imputed.data1[['day']]),
                                       learning_rate = control.ngd$learning.rate,
                                       max_iter = control.ngd$max.iter,
                                       epsilon = control.ngd$eps,
                                       message = control.ngd$messages)
        print("end estimating common odds ratio")
        # end model fitting
        common.or = as.numeric(exp(fit.common.odds.ratio$beta[1]))
        names(common.or) = treatment
        common.or.ci = exp(c(fit.common.odds.ratio$beta[1] - qnorm(1 - alpha / 2) * sqrt(fit.common.odds.ratio$cov[1, 1]),
                             fit.common.odds.ratio$beta[1] + qnorm(1 - alpha / 2) * sqrt(fit.common.odds.ratio$cov[1, 1])))
        common.or.ci = matrix(common.or.ci, ncol = 2)
        colnames(common.or.ci) = c(paste(100 * alpha / 2, '%', sep = ''), paste(100* (1 - alpha / 2), '%', sep = ''))
        row.names(common.or.ci) = treatment
        res$common.odds.ratio = list(estiamte = common.or, confidence.interval = common.or.ci)
    }
    
    if (piecewise.linear) {
        # fit proportional odds model with piecewise linear function
        # specify change points
        imputed.data2 = imputed.data[which(imputed.data$day >= start_time2 & imputed.data$day <= end_time2), ]
        if (is.null(knots)) {
            # default: every week
            if ((end_time2 - start_time2 + 1) %% 7 == 0) {
                num.weeks = (end_time2 - start_time2 + 1) / 7 - 1
            } else {
                num.weeks = (end_time2 - start_time2 + 1) %/% 7
            }
            change_points = start_time2 + 7 * (0:num.weeks)
            print(paste('knots:', paste(change_points, collapse = ", ")))
        } else {
            change_points = knots
        }
        # create covariates for piecewise linear model
        change_points_name = rep(NA, length(change_points))
        for (i in 1:length(change_points)) {
            change_points_name[i] = paste0(treatment, '_knot', i)
            imputed.data2[[change_points_name[i]]] = imputed.data2[["treatment"]] * pmax(imputed.data2[['day']] - change_points[i], 0)
        }
        if (intercept) {
            rm_col = which(colnames(imputed.data2) %in% c('score', 'day', 'id'))
        } else {
            rm_col = which(colnames(imputed.data2) %in% c('score', 'day', 'id', 'treatment'))
        }
        X.piecewise.linear = data.matrix(imputed.data2[, -rm_col])
        
        # start model fitting
        print("start fitting piecewise linear model")
        fit.piecewise.linear = po_gee(S = imputed.data2[['score']], 
                                      X = X.piecewise.linear,
                                      subject = as.character(imputed.data2[['id']]),
                                      time = as.numeric(imputed.data2[['day']]),
                                      learning_rate = control.ngd$learning.rate,
                                      max_iter = control.ngd$max.iter,
                                      epsilon = control.ngd$eps,
                                      message = control.ngd$messages)
        print("end fitting piecewise linear model")
        # end model fitting
        
        # get coefficient estiamtes for piecewise linear model
        coef.est = as.numeric(fit.piecewise.linear$beta)
        names(coef.est) = colnames(X.piecewise.linear)
        if (intercept) {
            keep_coef = c('treatment', change_points_name)
            keep_coef2 = c(treatment, change_points_name)
        } else {
            keep_coef = change_points_name
            keep_coef2 = change_points_name
        }
        
        keep_col = which(names(coef.est) %in% keep_coef)
        coef.est2 = coef.est[keep_col]
        var.est2 = fit.piecewise.linear$cov[keep_col, keep_col]
        names(coef.est2) = keep_coef2
        colnames(var.est2) = keep_coef2
        row.names(var.est2) = keep_coef2
        # contruct data frame for plot
        x = seq(start_time2, end_time2, 0.1)
        xx = NULL
        for (i in 1:length(change_points)) {
            xx =  cbind(xx, pmax(x - change_points[i], 0))
        }
        
        if (intercept) {
            xx = cbind(1, xx)
        }
        xx = as.matrix(xx)
        or.piecewise = exp(as.numeric(xx %*% coef.est2))
        or.piecewise.min = rep(NA, length(or.piecewise))
        or.piecewise.max = rep(NA, length(or.piecewise))
        for (i in 1:length(or.piecewise)) {
            or.piecewise.min[i] = exp(log(or.piecewise[i]) - qnorm(1 - alpha / 2) * as.numeric(sqrt(t(xx[i,]) %*% var.est2 %*% xx[i,])))
            or.piecewise.max[i] = exp(log(or.piecewise[i]) + qnorm(1 - alpha / 2) * as.numeric(sqrt(t(xx[i,]) %*% var.est2 %*% xx[i,])))
        }
        or.pl = data.frame(or = or.piecewise, or_min = or.piecewise.min, or_max = or.piecewise.max, t = x)
        
        
        # fit separate proportional odds models for each day
        imputed.data3 = imputed.data[which(imputed.data$day >= start_time2 & imputed.data$day <= end_time2), ]
        or.separate = rep(NA, end_time2 - start_time2 + 1)
        or.separate.min = rep(NA, end_time2 - start_time2 + 1)
        or.separate.max = rep(NA, end_time2 - start_time2 + 1)
        print('start fitting separate proportional odds models')
        for (i in 1:(end_time2 - start_time2 + 1)) {
            tt = start_time2 + i - 1
            tmp = imputed.data3[which(imputed.data3[['day']] == tt),]
            # start model fitting
            rm_col = which(colnames(tmp) %in% c('score', 'day', 'id'))
            X.separate = data.matrix(tmp[, -rm_col])
            fit.separate = po_gee(S = tmp[['score']], 
                                  X = X.separate,
                                  subject = as.character(tmp[['id']]),
                                  time = as.numeric(tmp[['day']]),
                                  learning_rate = control.ngd$learning.rate,
                                  max_iter = control.ngd$max.iter,
                                  epsilon = control.ngd$eps,
                                  message = control.ngd$messages)
            # end model fitting
            or.separate[i] = exp(fit.separate$beta[1])
            or.separate.min[i] = exp(fit.separate$beta[1] - qnorm(1 - alpha / 2) * sqrt(fit.separate$cov[1, 1]))
            or.separate.max[i] = exp(fit.separate$beta[1] + qnorm(1 - alpha / 2) * sqrt(fit.separate$cov[1, 1]))
        }
        print('end fitting separate proportional odds models')
        or.sep = data.frame(or = or.separate, or_min = or.separate.min, or_max = or.separate.max, t = start_time2:end_time2)
        or.sep2 = data.frame(or.sep$t, or.sep$or, or.sep$or_min, or.sep$or_max)
        colnames(or.sep2) = c('Time', 'Odds Ratio', paste(100 * alpha / 2, '%', sep = ''), paste(100 * (1 - alpha / 2), '%', sep = ''))
        res$separate.model = or.sep2
        
        # plot
        p <- ggplot() +
            geom_line(data = or.pl,
                      aes(x = t, y = or, colour = 'red'),
                      show.legend = F) +
            geom_ribbon(data = or.pl,
                        aes(x = t,
                            ymin = or_min,
                            ymax = or_max,
                            fill = 'red'),
                        alpha = 0.2, show.legend = F) +
            geom_point(data = or.sep,
                       aes(x = t, y = or, colour = 'blue'),
                       show.legend = F) +
            geom_errorbar(data = or.sep,
                          aes(x = t,
                              ymin = or_min,
                              ymax = or_max,
                              colour = 'blue'),
                          show.legend = F) +
            scale_x_continuous(breaks = start_time2:end_time2) +
            scale_color_identity() +
            ylab('Odds ratio') +
            xlab('Day') +
            theme_classic()
        p
        res$piecewise.linear = list(knots = change_points,
                                    estimate = coef.est2,
                                    var = var.est2,
                                    intercept = intercept,
                                    plot = p)
    }
    
    
    return(res)
}
