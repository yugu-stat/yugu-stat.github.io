#' @keywords internal
last_obs_carried_forward = function(data, score, subject, time, start.time, end.time, imputed.score) {
    data.id = data[[subject]]
    data.time = as.numeric(data[[time]])
    data.sorted = data[order(data.id, data.time),]
    unique.id = unique(data.id)
    data.imputed = NULL
    for (sub in unique.id) {
        data.sub = data.sorted[which(data.sorted[[subject]] == sub),]
        obs.time.sub = as.numeric(data.sub[[time]])
        data.sub.imputed = NULL
        if(is.na(obs.time.sub[1])) {
            data.sub[[score]] = imputed.score
            for (t0 in start.time:end.time) {
                data.sub.imputed = rbind(data.sub.imputed, data.sub)
            }
            data.sub.imputed = data.frame(data.sub.imputed)
            data.sub.imputed$time_imputed = start.time:end.time
            data.imputed = rbind(data.imputed, data.sub.imputed)
            next
        }
        i = 1
        while (i <= length(obs.time.sub) & obs.time.sub[i] < start.time) {
            i = i + 1
        }
        for (t0 in start.time:end.time) {
            # has observation
            if (i <= length(obs.time.sub) & t0 == obs.time.sub[i]) {
                data.sub.imputed = rbind(data.sub.imputed, data.sub[i,])
                i = i + 1
            } else {
                # do not have observation before last visit
                if (i <= length(obs.time.sub) & t0 < obs.time.sub[i]) {
                    data.sub.imputed = rbind(data.sub.imputed, data.sub[i-1,])
                } else if (i > length(obs.time.sub)) {
                    if (i != length(obs.time.sub) + 1) {
                        warning("imputation error1")
                    }
                    data.sub.imputed = rbind(data.sub.imputed, data.sub[i-1,])
                } else {
                    stop("imputation error2")
                }
            }
        }
        data.sub.imputed = data.frame(data.sub.imputed)
        data.sub.imputed$time_imputed = start.time:end.time
        data.imputed = rbind(data.imputed, data.sub.imputed)
    }
    data.imputed = data.frame(data.imputed)
    data.imputed[[time]] = data.imputed$time_imputed
    rm_col = which(colnames(data.imputed) == 'time_imputed')
    data.imputed2 = data.imputed[, -rm_col]
    return(data.imputed2)
}
