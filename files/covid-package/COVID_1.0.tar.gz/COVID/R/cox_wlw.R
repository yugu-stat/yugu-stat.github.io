# Internal function
# Derive times of multiple events
get_event_time = function(df, vnames, Kimp, Kdet) {
  
  Kben = Kimp+Kdet
  info = df[1,]
  imp.time = imp.status = rep(NA, Kimp)
  det.time = det.status = rep(NA, Kdet)
  
  # improvement
  for(i in 1:Kimp) {
    temp = df$day[df$score0-df$score >= i]
    if(length(temp)>0) {
      # event time is the first time of observing an improvement by i categories
      # relative to the baseline score
      imp.time[i] = min(temp)
      imp.status[i] = 1
    } else if(info$score0-1 < i) {
      # not eligible for an improvement by i categories
      imp.time[i] = 0
      imp.status[i] = 0
    } else {
      # censored at the maxmal follow-up time
      imp.time[i] = max(df$day)
      imp.status[i] = 0
    }
  }
  
  # deterioration
  for(i in 1:Kdet) {
    temp = df$day[df$score-df$score0 >= i]
    if(length(temp)>0) {
      det.time[i] = min(temp)
      det.status[i] = 1
    } else if(8-info$score0 < i) {
      det.time[i] = 0
      det.status[i] = 0
    } else {
      det.time[i] = max(df$day)
      det.status[i] = 0
    }
  }
  
  # create long format of records for times of all events
  newdf = data.frame("treatment" = c(rep(info$treatment, Kimp),
                                     rep(1-info$treatment, Kdet)),
                     "score0" = rep(info$score0, Kben),
                     "enum" = 1:Kben,
                     "time" = c(imp.time, det.time),
                     "status" = c(imp.status, det.status))
  
  ncovar = length(vnames)
  if(ncovar>0) {
    Xind = colnames(info) %in% vnames
    newdf = cbind(newdf, 
                  matrix(unlist(info[,Xind]),
                         nrow = Kben,
                         ncol = ncovar,
                         byrow = T))
    
    colnames(newdf)[-(1:(ncol(newdf)-ncovar))] = vnames
  }
  
  return(newdf)
}


# Internal function
# Create data related to multiple events
# and fit marginal Cox models with WLW method
#' @import dplyr survival
analyze_cox_wlw = function(data, vnames, nmin, K) {
  # number of events
  score0 = sort(unique(data$score0))
  Kimp = max(score0)-1
  Kdet = K-min(score0)
  Kben = Kimp+Kdet
  
  data_ben = data %>%
    group_by(id) %>%
    group_modify(~ get_event_time(.x, vnames, Kimp, Kdet), .keep = TRUE) %>%
    as.data.frame()
  
  # check if #cases of a certain event is smaller than nmin
  evec = NULL
  for(i in 1:Kben) {
    nsubj = sum(data_ben$status[data_ben$enum==i])
    if(nsubj>=nmin) {
      evec = c(evec, i)
    } else {
      data_ben = data_ben %>%
        dplyr::filter(enum!=i)
      if(i <= Kimp) {
        message("Remove improvement by ", i, " categories due to very few cases.")
      } else {
        message("Remove deterioration by ", i-Kimp, " categories due to very few cases.")
      }
      
    }
  }
  
  ####################################################################################
  ### fit marginal Cox models stratified by baseline score,
  #### using robust covariance estimation (WLW method)
  
  # add backticks to variable names
  vnames.backtick = sprintf("`%s`", vnames)
  
  if(!is.null(vnames)) {
    model = as.formula(sprintf("Surv(time, status) ~ strata(score0, enum) + treatment:strata(enum)+%s + cluster(id)", 
                               paste(vnames.backtick, "strata(enum)", 
                                     sep = ":", collapse = "+")))
  } else {
    model = as.formula("Surv(time, status) ~ strata(score0, enum) + treatment:strata(enum) + cluster(id)")
  }
  
  fit = coxph(model, data = data_ben, ties = "breslow")
  # treatment effects
  pgamma = length(evec)
  gamma = fit$coefficients[1:pgamma]
  attributes(gamma) = NULL
  
  # robust covariance estimator 
  psi = fit$var[1:pgamma, 1:pgamma]
  # Z-score
  Zscore = gamma/sqrt(diag(psi))
  # combined Z-score test: improvement, deterioration, total benefit
  temp = diag(psi)^{-1/2}
  # test statistic
  impind = which(evec<=Kimp)
  detind = which(evec>Kimp)
  Timp = sum(Zscore[impind])/sqrt(temp[impind] %*% psi[impind, impind] %*% temp[impind])
  Tdet = -sum(Zscore[detind])/sqrt(temp[detind] %*% psi[detind, detind] %*% temp[detind])
  Tben = sum(Zscore)/sqrt(temp %*% psi %*% temp)
  # two-sided p-value
  pimp = 2*pnorm(abs(Timp), lower.tail = F)
  pdet = 2*pnorm(abs(Tdet), lower.tail = F)
  pben = 2*pnorm(abs(Tben), lower.tail = F)
  
  # common treatment effect: improvement, deterioration, total benefit
  gamma_imp = sum(Zscore[impind])/sum(temp[impind])
  gamma_det = -sum(Zscore[detind])/sum(temp[detind])
  gamma_ben = sum(Zscore)/sum(temp)
  # standard error for common treatment effect estimators
  coef_imp = c(temp[impind], rep(0, length(detind)))
  se_gamma_imp = sqrt(coef_imp %*% psi %*% coef_imp)/sum(temp[impind])
  coef_det = c(rep(0, length(impind)), temp[detind])
  se_gamma_det = sqrt(coef_det %*% psi %*% coef_det)/sum(temp[detind])
  coef_ben = temp
  se_gamma_ben = sqrt(coef_ben %*% psi %*% coef_ben)/sum(temp)
  
  # summarize the results
  logHR = c(gamma_imp, gamma_det, gamma_ben)
  selogHR = c(se_gamma_imp, se_gamma_det, se_gamma_ben)
  lower = exp(logHR-1.96*selogHR)
  upper = exp(logHR+1.96*selogHR)
  pval = c(pimp, pdet, pben)
  wlw_res = cbind(exp(logHR), lower, upper, pval)
  rownames(wlw_res) = c("imp", "det", "ben")
  ####################################################################################
  
  
  ####################################################################################
  ### fit separate models for each type of event (stratified by baseline score)
  sep_gamma = sep_se = sep_pval = rep(NA, Kben)
  for(i in evec) {
    subdata = dplyr::filter(data_ben, enum==i)
    if(!is.null(vnames)) {
      sep_model = as.formula(sprintf("Surv(time, status) ~ strata(score0) + treatment + %s +
                  cluster(id)", paste(vnames.backtick, collapse = "+")))
    } else {
      sep_model = as.formula("Surv(time, status) ~ strata(score0) + treatment +
                  cluster(id)")
    }
    
    fit = coxph(sep_model, data = subdata, ties = "breslow")
    fit = summary(fit)$coef[1,]
    sep_gamma[i] = fit[1]
    if(i>Kimp) {
      # flip the treatment effect for deterioration
      sep_gamma[i] = -sep_gamma[i]
    }
    sep_se[i] = fit[4]
    sep_pval[i] = fit[6]
  }
  # sep_gamma and gamma from marginal models are exactly the same
  HR = exp(sep_gamma)
  lower = exp(sep_gamma-1.96*sep_se)
  upper = exp(sep_gamma+1.96*sep_se)
  sep_res = cbind(HR, lower, upper, sep_pval)
  ####################################################################################
  
  
  ####################################################################################
  ### summarized the results from all three analyses in a single Table  
  outsum = rbind(sep_res[evec[impind],],
                 wlw_res[1,],
                 sep_res[evec[detind],],
                 wlw_res[-1,])
  colnames(outsum) = c("HR", "Lower .95", "Upper .95", "P")
  rownames(outsum) = c("Improvement by 1 category",
            sprintf("Improvement by %d categories", evec[impind[-1]]),
            # "Improvement by 2 categories",
            # "Improvement by 3 categories",
            # "Improvement by 4 categories",
            # "Improvement by 5 categories",
            # "Improvement by 6 categories",
            "Any improvement (WLW_imp)",
            "Deterioration by 1 category",
            sprintf("Deterioration by %d categories", evec[detind[-1]]-Kimp),
            # "Deterioration by 2 categories",
            # "Deterioration by 3 categories",
            # "Deterioration by 4 categories",
            "Any deterioration (WLW_det)",
            "Overall benefit (WLW_ben)")
  
  return(outsum)
  
}

