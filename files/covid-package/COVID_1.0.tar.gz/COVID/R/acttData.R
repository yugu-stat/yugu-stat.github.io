#' Toy Dataset For Illustration
#'
#' This data set is provided to illustrate the use of
#' the software. 
#' It is a randomly scrambled subset of the actual ACTT-1 trial data.
#' 
#' @usage data(acttData)
#'
#' @format acttData is a data.frame containing 500 subjects who were followed for 
#'   up to 29 days. The data.frame contains 8 columns, 
#'   \describe{
#'   \item{subject_id}{Subject ID.}
#'   \item{treatment_arm}{A binary indicator of treatment arm (0: placebo; 1: remdesivir).}
#'   \item{initial_status}{The initial clinical status at randomization, 
#'     can be 4, 5, 6, or 7.}
#'   \item{clinical_status}{The clinical status at each examination, can be 1, 2, ..., 8.}
#'   \item{examination_time}{The examination times in days.}
#'   \item{baseline_severity}{The baseline disease severity, Mild-Moderate Disease or Severe Disease.}
#'   \item{age}{Age in years.}
#'   \item{sex}{A binary indicator of sex (F/M).}
#'   }
#'
#' @name acttData
#' @keywords datasets
NULL